import java.util.*;

public class Collections{

	public static void main(String[] args) {
		//creating arraylist
		System.out.println("ArrayList");
		ArrayList<String> fruits=new ArrayList<String>();   
	      fruits.add("Mango");//
	      fruits.add("Stawberry");    	   
	      System.out.println(fruits);  
		
		//creating vector
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vec = new Vector();
	      vec.addElement(25); 
	      vec.addElement(40); 
	      System.out.println(vec);
		
		//creating linkedlist
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> flowers=new LinkedList<String>();  
	      flowers.add("Lilly");  
	      flowers.add("Marigold");  	      
	      Iterator<String> itr=flowers.iterator();  
	      
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	      }
	       //creating hashset
	       System.out.println("\n");
	       System.out.println("HashSet");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(75);  
	       set.add(72);  
	       set.add(74);
	       set.add(73);
	       System.out.println(set);
	       
	       //creating linkedhashset
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(100);  
	       set2.add(98);  
	       set2.add(99);
	       set2.add(97);	       
	       System.out.println(set2);
	      	
	      }  
	}
