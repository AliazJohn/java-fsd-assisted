public class TypeCasting {
public static void main(String[] args) {
		
		//implicit conversion
		System.out.println("Implicit Type Casting");
		char x='X';
		System.out.println("Value of a: "+x);
		
		int y=x;
		System.out.println("Value of b: "+y);
		
		float z=x;
		System.out.println("Value of c: "+z);
		
		long p=x;
		System.out.println("Value of d: "+p);
		
		double q=x;
		System.out.println("Value of e: "+q);
		
		
		//explicit conversion
		System.out.println("\nExplicit Type Casting");
		
		double r=15.5;
		int s=(int)r;
		System.out.println("Value of x: "+r);
		System.out.println("Value of y: "+s);
		
	}
}
