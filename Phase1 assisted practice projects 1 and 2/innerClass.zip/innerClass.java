//anonymous inner classs
abstract class AnonymousInnerClass {
	   public abstract void display();
	}
//Inner Class block
public class innerClass {
	private String msg="hi, all"; 
	class Inner{  
		void hello(){
			System.out.println(msg+" good morning");
			}  
	 	}  

	//Method local inner class block
	private String msg1="Inner Classes";
	void display1(){  
		 class Inner1{  
			 void msg1(){
				 System.out.println(msg1);
			 }  
	  }  
	  
	  Inner1 l=new Inner1();  
	  l.msg1();  
	 }  
	

public static void main(String[] args) {
		//inner class
		innerClass obj=new innerClass();
		innerClass.Inner in=obj.new Inner();  
		in.hello();  
		
		//Method local inner class
		obj.display1();
		
		//Anonymous Inner Class
		AnonymousInnerClass i = new AnonymousInnerClass() {
			public void display() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      i.display();

	}
}
