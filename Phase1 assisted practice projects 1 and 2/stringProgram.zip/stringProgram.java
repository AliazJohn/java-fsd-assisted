public class stringProgram {


	public static void main(String[] args) {
 
		System.out.println("Creating StringBuffer:");
		//Creating string using StringBuffer
		StringBuffer s=new StringBuffer("Hello world!!!");
		System.out.println(s);

		//Creating string using StringBuilder

		System.out.println("Creating StringBuilder:");
		StringBuilder sb1=new StringBuilder("Good to see y'all");
		System.out.println(sb1);

		//conversion	

		System.out.println("\nConversion of Strings to StringBuffer and StringBuilder");
        
        // conversion from String object to StringBuffer 
		String str = "Good morning!!!"; 
        StringBuffer sbr = new StringBuffer(str); 
        System.out.println("String to StringBuffer:");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        String str1 = "Good night!!!";
        StringBuilder sbl = new StringBuilder(str1); 
        System.out.println("String to StringBuilder:");
        System.out.println(sbl);              		
	}
}
