import java.util.regex.*;

public class regex {
public static void main(String[] args) {

	String pattern = "[a-z]+";
	String check = "Hello World";
	Pattern p = Pattern.compile(pattern);
	//checking whether the pattern matches
	Matcher c = p.matcher(check);
	System.out.println(c.matches());
	while (c.find())
      	System.out.println( check.substring( c.start(), c.end() ) );
	
	String test="haaai";
	//checking whether the pattern matches	
	Matcher d = p.matcher(test);
	System.out.println(d.matches());
	}
}
