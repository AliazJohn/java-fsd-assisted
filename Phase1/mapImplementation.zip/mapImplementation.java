import java.util.*;
public class mapImplementation {

	public static void main(String[] args) {
		HashMap<Integer,String> hash=new HashMap<Integer,String>();      
		hash.put(1,"Lilly");    
		hash.put(2,"Marigold");    
		hash.put(3,"Orchid");   
	       
	      System.out.println("Hashmap: ");  
	      for(Map.Entry m:hash.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	       
	      Hashtable<Integer,String> hasht=new Hashtable<Integer,String>();  
	      
	      hasht.put(1,"Mango");  
	      hasht.put(2,"Apple");  
	      hasht.put(3,"Blueberry");  
	      hasht.put(4,"Orange");  

	      System.out.println("\nHashTable:");  
	      for(Map.Entry n:hasht.entrySet()){    
	       System.out.println(n.getKey()+" "+n.getValue());    
	      }
	      
	      
	      TreeMap<Integer,String> tmap=new TreeMap<Integer,String>();    
	      tmap.put(1,"Potato");    
	      tmap.put(2,"Carrot");    
	      tmap.put(3,"Onion");       
	      
	      System.out.println("\nTreeMap: ");  
	      for(Map.Entry l:tmap.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  
}

