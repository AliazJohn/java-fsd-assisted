public class EmployeeConstructor {
	int empId;
	String empName;
	String department;
	float salary;
	
	//default constructor
	public EmployeeConstructor() {
		empId=180893;
		empName="Rahul";
		department="Accounting";
		salary=50000;
	}
	
	//parameterised constructor
	public EmployeeConstructor(int empId, String empName, String department, float salary) {
		this.empId=empId;
		this.empName=empName;
		this.department=department;
		this.salary=salary;
	}
	
	public void display() {
		System.out.println("Id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("Department: "+department);
		System.out.println("Salary: "+salary);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		EmployeeConstructor obj= new EmployeeConstructor();
		EmployeeConstructor obj1= new EmployeeConstructor(180894, "Sinha", "Production", 60000); 

		//invoking default constructor
		obj.display();
		//invoking parameterised constructor
		obj1.display();
		}
}
