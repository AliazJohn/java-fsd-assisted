public class arrayPgm {
	public static void main(String[] args) {
		//single-dimensional array
		int a[]= {1,2,3,4,5,6,7,8,9};
		System.out.println("Elements of array a: ");
		for(int i=0;i<9;i++) {
		System.out.print(a[i]+" ");
		}
		//multidimensional array
		int[][] b = {
				{2, 4, 6, 8},
				{3, 6, 9}
				};
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      System.out.println("Length of row 2: " + b[1].length);
		      System.out.println("First row second element is: "+b[0][1]);
		      }
		}


