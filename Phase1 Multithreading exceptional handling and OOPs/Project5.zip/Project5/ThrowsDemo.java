package AssistedPractice.Project5;

public class ThrowsDemo
{
    void Division() throws ArithmeticException
    {
    	int x=25,y=0,res;
    	res=x/y;
        System.out.print("Sum is : " + res);
    }
     public static void main(String[] args)
    {
    	 ThrowsDemo T = new ThrowsDemo();
         try
         {
            T.Division();
         }
         catch(ArithmeticException e)
         {
        	 System.out.print("Error is: " + e.getMessage());
         }
    }
}

