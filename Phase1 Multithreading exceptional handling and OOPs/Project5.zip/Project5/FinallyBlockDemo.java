package AssistedPractice.Project5;

public class FinallyBlockDemo {
	public static void main(String[] args)
    {
        int x=45,y=0,res=0;
        try
        {
            res = x/y;
        }
        catch(ArithmeticException e)
        {
            System.out.print("Error is: " + e.getMessage());
        }
        finally
        {
            System.out.print("\nThe result is : " + res);
        }
    }

}
