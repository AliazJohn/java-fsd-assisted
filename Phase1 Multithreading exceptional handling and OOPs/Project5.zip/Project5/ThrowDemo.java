package AssistedPractice.Project5;

public class ThrowDemo {
        public static void main(String[] args)
        {
        	int x=25,y=0,res;
        	try
            {
                if(y==0)        
                    throw(new ArithmeticException("Can't divide by zero."));
                else
                {
                    res = x / y;
                    System.out.print("The result is : " + res);
                }
            }
            catch(ArithmeticException e)
            {
                System.out.print("Error : " + e.getMessage());
            }
        }
}
