package AssistedPractice.Project8;

public class ObjectClassDemo {

	 int id;
	 String name;
	String email;
	
	public ObjectClassDemo(int id, String email, String name) {
		this.id=id;
		this.email=email;
		this.name=name;
		
	}
	 
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}
	
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", email=" + email + "]";
	}
		public static void main(String args[]) {
			ObjectClassDemo obj=new ObjectClassDemo(1212,"al@kmail.com","alex");
			System.out.println("Employee details are: \nid: " +obj.getId() +"\nname: "+obj.getName() +"\nemail id: " +obj.getEmail());
		}
	}