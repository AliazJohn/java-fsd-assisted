package AssistedPractice.Project8;

public class EncapsulationDemo 
{     
    public static void main (String[] args)  
    { 
        StudentEncapTest obj = new StudentEncapTest(); 
        obj.setName("adolf"); 
        obj.setAge(15); 
        obj.setRoll(1); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());      
    } 
}

