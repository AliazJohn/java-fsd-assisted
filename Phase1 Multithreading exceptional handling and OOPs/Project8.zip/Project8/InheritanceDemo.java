package AssistedPractice.Project8;

class car  
{ 
    public int seat; 
    public int speed; 
    public car(int seat, int speed) 
    { 
        this.seat = seat; 
        this.speed = speed; 
    } 
   
    public String toString()  
    { 
        return("No of seats are " + seat + "\n" + "speed of car is " + speed); 
    }  
} 
class suv extends car 
{ 
    public int cc; 
    public suv(int seat,int speed,int cc1) 
    {  
        super(seat, speed); 
        cc=cc1; 
    }  
    public void cc(int newValue) 
    { 
        cc = newValue; 
    } 

    public String toString() 
    { 
        return (super.toString()+ 
                "\ncubic capacity is "+cc); 
    } 
}
public class InheritanceDemo  
{ 
    public static void main(String args[]){ 
        suv s = new suv(3, 100, 25); 
        System.out.println(s.toString());
    } 
}
