package AssistedPractice.Project8;

class PolymorphismDemo{
    public int display(int x) 
    { 
        return (x); 
    } 
    public int display(char c) 
    { 
        System.out.print("ascii of "+c +" is "); 
        return(c);
    }  
    public static void main(String[] args) 
    { 
        PolymorphismDemo p = new PolymorphismDemo(); 
       
        System.out.println(p.display(10)); 
        System.out.println(p.display('A')); 
    } 
}

