package AssistedPractice.Project1;

public class MyRunnableThread implements  Runnable{
public  void run() {
		//to view the run() method working using runnable interface by using two thread class objects
		for(int i=1; i<5; i++) {
			System.out.println(Thread.currentThread()+" count "+i);
		}
	}
	
	
	public static void main(String[] args) {
		
		MyRunnableThread ins1= new MyRunnableThread();
		MyRunnableThread ins2= new MyRunnableThread();
		
		Thread t1=new  Thread(ins1);
		Thread t2=new  Thread(ins2);
		
	
		t1.start(); //thread 0
		t2.start(); //thread 1
	}
}
