package AssistedPractice.Project1;

public class Mythread extends Thread{
	//method over loading
		public void run() {
			System.out.println("thread Started to run!");
		}
		
		public static void main(String[] args) {
			
			Mythread t1= new Mythread();
			Mythread t2= new  Mythread();
			
			t1.start();
			t2.start();
		}

}
