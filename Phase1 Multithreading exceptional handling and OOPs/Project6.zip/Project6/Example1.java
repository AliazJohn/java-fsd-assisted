package AssistedPractice.Project6;

class CustomException extends Exception{
	   String str1;
	   CustomException(String str2) {
		str1=str2;
	   }
	   public String toString(){ 
		return ("Exception Occurred: "+str1) ;
	   }
	}
	class Example1{
	   public static void main(String args[]){
		try{
			System.out.println("Starting of try block....");
			//A custom exception is created and throwing that exception
			throw new CustomException("This is Custom exception");
		}
		catch(CustomException exp){
			System.out.println("_____Catch Block_____") ;
			System.out.println(exp) ;
		}
	   }
	}
