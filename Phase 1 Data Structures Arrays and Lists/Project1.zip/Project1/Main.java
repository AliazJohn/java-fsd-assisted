package AssistedPractice.Project1;
public class Main
{
	public static void main(String[] args) {
		ArrayRotate r = new ArrayRotate();
        		int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9}; 
        		r.rotate(a, 6); 
        		for(int i=0;i<a.length;i++){
            			System.out.print(a[i]+" ");
        		}
	}
}
