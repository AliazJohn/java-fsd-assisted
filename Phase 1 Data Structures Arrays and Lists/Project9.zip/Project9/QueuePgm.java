package AssistedPractice.Project9;

import java.util.LinkedList;
import java.util.Queue;

public class QueuePgm{
	
	public static void main(String[] args) {
		Queue<String> locationQueue= new LinkedList<String>();
		locationQueue.add("USA");
		locationQueue.add("India");
		locationQueue.add("Srilanka");
		locationQueue.add("Nepal");
		locationQueue.add("Ireland");
		locationQueue.add("Saudi Arabia");
		
		System.out.println("Queue is : "+locationQueue);

		System.out.println("Head of the Queue: "+locationQueue.peek());
		
		locationQueue.remove();
		
		System.out.println("After Removing Head: "+locationQueue);
		
		System.out.println("New Head of the Queue is: "+locationQueue.peek());
		
		System.out.println("Size of the Queue is: "+locationQueue.size());
		
	}

}